package com.example.moblab11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
